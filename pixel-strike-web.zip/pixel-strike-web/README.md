# Pixel Strike — publish it (no setup needed)

Everything in this folder is the whole game. Progress (accounts, rank, coins, knives) saves on each player's own device.

## Publish with GitHub Pages (free, about 5 minutes)

1. Make a free account at https://github.com and click **New repository**. Name it `pixel-strike`, set it to **Public**, then **Create repository**.
2. Click **uploading an existing file** (or **Add file → Upload files**). Drag in **everything in this folder**, including the `knives` folder, then click **Commit changes**.
3. Go to **Settings → Pages**. Under **Branch**, pick `main` and `/ (root)`, then **Save**.
4. Wait about a minute and refresh. Your game is at `https://YOUR-USERNAME.github.io/pixel-strike/`.

**On iPad:** open that link in Safari → Share → **Add to Home Screen**. It opens full screen like an app.

**To update the game later:** upload the new `index.html` to the same repository; the site updates in a minute.

## Good to know

- Saves stay on the device and browser they were made on. Clearing Safari's website data, or using a different iPad, starts fresh. Players can use **Settings → Copy my backup code** to carry progress to another device.
- The leaderboard shows players who have played on that same device.
- Want shared saves and a school-wide leaderboard later? The cloud version can be added on top of this without changing how players play.
